import{aD as t}from"./-GGzIt9t.js";const a=t({cast(r){return r==="number"?{ratingValue:r}:r},defaults:{"@type":"Rating",bestRating:5,worstRating:1}});export{a as r};
