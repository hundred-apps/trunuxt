const a=e=>e?e.toLowerCase().replace(/\b\w/g,r=>r.toUpperCase()).replace(/[^a-zA-Z0-9]+/g,"-").replace(/^-+|-+$/g,""):"";export{a as f};
