import{aC as e}from"./C_RlNlXh.js";const r=e({defaults:{"@type":"PostalAddress"}});export{r as addressResolver};
