import{_ as e,o as c,c as t}from"./C_RlNlXh.js";const n={},o={style:{padding:"20px"}};function s(r,_){return c(),t("div",o)}const d=e(n,[["render",s]]);export{d as default};
