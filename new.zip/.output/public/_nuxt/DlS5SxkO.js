import{aD as t}from"./-GGzIt9t.js";const s=t({defaults:{"@type":"ReadAction"},resolve(e,r){return e.target.includes(r.meta.url)||e.target.unshift(r.meta.url),e}});export{s as readActionResolver};
