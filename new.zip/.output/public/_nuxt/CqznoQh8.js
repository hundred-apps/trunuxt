import{aC as t}from"./C_RlNlXh.js";const a=t({cast(r){return typeof r=="string"?{url:r}:r},defaults:{"@type":"VirtualLocation"}});export{a as virtualLocationResolver};
