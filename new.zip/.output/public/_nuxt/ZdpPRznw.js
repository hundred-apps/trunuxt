import{aD as e}from"./-GGzIt9t.js";const g=e({defaults:{"@type":"AggregateRating"}});export{g as aggregateRatingResolver};
