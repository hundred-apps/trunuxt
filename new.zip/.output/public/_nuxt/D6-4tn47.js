import{aD as e}from"./-GGzIt9t.js";const s=e({defaults:{"@type":"OpeningHoursSpecification",opens:"00:00",closes:"23:59"}});export{s as openingHoursResolver};
