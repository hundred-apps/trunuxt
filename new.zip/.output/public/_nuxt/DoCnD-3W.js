import{aC as t}from"./C_RlNlXh.js";const a=t({cast(r){return r==="number"?{ratingValue:r}:r},defaults:{"@type":"Rating",bestRating:5,worstRating:1}});export{a as r};
