import{aD as e}from"./-GGzIt9t.js";const r=e({defaults:{"@type":"PostalAddress"}});export{r as addressResolver};
