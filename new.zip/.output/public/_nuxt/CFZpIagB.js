import{aC as e}from"./C_RlNlXh.js";const g=e({defaults:{"@type":"AggregateRating"}});export{g as aggregateRatingResolver};
