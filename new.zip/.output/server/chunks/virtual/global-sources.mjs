const sources = [
    {
        "context": {
            "name": "nuxt:pages",
            "description": "Generated from your static page files.",
            "tips": [
                "Can be disabled with `{ excludeAppSources: ['nuxt:pages'] }`."
            ]
        },
        "urls": [
            {
                "loc": "/principal/machining",
                "_sitemap": "id-ID",
                "alternatives": [
                    {
                        "hreflang": "id-ID",
                        "href": "/principal/machining"
                    },
                    {
                        "hreflang": "en-US",
                        "href": "/en/principal/machining"
                    },
                    {
                        "hreflang": "zh-CN",
                        "href": "/zh/principal/machining"
                    },
                    {
                        "hreflang": "x-default",
                        "href": "/principal/machining"
                    }
                ]
            },
            {
                "loc": "/en/principal/machining",
                "_sitemap": "en-US",
                "alternatives": [
                    {
                        "hreflang": "id-ID",
                        "href": "/principal/machining"
                    },
                    {
                        "hreflang": "en-US",
                        "href": "/en/principal/machining"
                    },
                    {
                        "hreflang": "zh-CN",
                        "href": "/zh/principal/machining"
                    },
                    {
                        "hreflang": "x-default",
                        "href": "/principal/machining"
                    }
                ]
            },
            {
                "loc": "/zh/principal/machining",
                "_sitemap": "zh-CN",
                "alternatives": [
                    {
                        "hreflang": "id-ID",
                        "href": "/principal/machining"
                    },
                    {
                        "hreflang": "en-US",
                        "href": "/en/principal/machining"
                    },
                    {
                        "hreflang": "zh-CN",
                        "href": "/zh/principal/machining"
                    },
                    {
                        "hreflang": "x-default",
                        "href": "/principal/machining"
                    }
                ]
            },
            {
                "loc": "/principal/struman",
                "_sitemap": "id-ID",
                "alternatives": [
                    {
                        "hreflang": "id-ID",
                        "href": "/principal/struman"
                    },
                    {
                        "hreflang": "en-US",
                        "href": "/en/principal/struman"
                    },
                    {
                        "hreflang": "zh-CN",
                        "href": "/zh/principal/struman"
                    },
                    {
                        "hreflang": "x-default",
                        "href": "/principal/struman"
                    }
                ]
            },
            {
                "loc": "/en/principal/struman",
                "_sitemap": "en-US",
                "alternatives": [
                    {
                        "hreflang": "id-ID",
                        "href": "/principal/struman"
                    },
                    {
                        "hreflang": "en-US",
                        "href": "/en/principal/struman"
                    },
                    {
                        "hreflang": "zh-CN",
                        "href": "/zh/principal/struman"
                    },
                    {
                        "hreflang": "x-default",
                        "href": "/principal/struman"
                    }
                ]
            },
            {
                "loc": "/zh/principal/struman",
                "_sitemap": "zh-CN",
                "alternatives": [
                    {
                        "hreflang": "id-ID",
                        "href": "/principal/struman"
                    },
                    {
                        "hreflang": "en-US",
                        "href": "/en/principal/struman"
                    },
                    {
                        "hreflang": "zh-CN",
                        "href": "/zh/principal/struman"
                    },
                    {
                        "hreflang": "x-default",
                        "href": "/principal/struman"
                    }
                ]
            },
            {
                "loc": "/principal/usedsparepart",
                "_sitemap": "id-ID",
                "alternatives": [
                    {
                        "hreflang": "id-ID",
                        "href": "/principal/usedsparepart"
                    },
                    {
                        "hreflang": "en-US",
                        "href": "/en/principal/usedsparepart"
                    },
                    {
                        "hreflang": "zh-CN",
                        "href": "/zh/principal/usedsparepart"
                    },
                    {
                        "hreflang": "x-default",
                        "href": "/principal/usedsparepart"
                    }
                ]
            },
            {
                "loc": "/en/principal/usedsparepart",
                "_sitemap": "en-US",
                "alternatives": [
                    {
                        "hreflang": "id-ID",
                        "href": "/principal/usedsparepart"
                    },
                    {
                        "hreflang": "en-US",
                        "href": "/en/principal/usedsparepart"
                    },
                    {
                        "hreflang": "zh-CN",
                        "href": "/zh/principal/usedsparepart"
                    },
                    {
                        "hreflang": "x-default",
                        "href": "/principal/usedsparepart"
                    }
                ]
            },
            {
                "loc": "/zh/principal/usedsparepart",
                "_sitemap": "zh-CN",
                "alternatives": [
                    {
                        "hreflang": "id-ID",
                        "href": "/principal/usedsparepart"
                    },
                    {
                        "hreflang": "en-US",
                        "href": "/en/principal/usedsparepart"
                    },
                    {
                        "hreflang": "zh-CN",
                        "href": "/zh/principal/usedsparepart"
                    },
                    {
                        "hreflang": "x-default",
                        "href": "/principal/usedsparepart"
                    }
                ]
            },
            {
                "loc": "/article",
                "_sitemap": "id-ID",
                "alternatives": [
                    {
                        "hreflang": "id-ID",
                        "href": "/article"
                    },
                    {
                        "hreflang": "en-US",
                        "href": "/en/article"
                    },
                    {
                        "hreflang": "zh-CN",
                        "href": "/zh/article"
                    },
                    {
                        "hreflang": "x-default",
                        "href": "/article"
                    }
                ]
            },
            {
                "loc": "/en/article",
                "_sitemap": "en-US",
                "alternatives": [
                    {
                        "hreflang": "id-ID",
                        "href": "/article"
                    },
                    {
                        "hreflang": "en-US",
                        "href": "/en/article"
                    },
                    {
                        "hreflang": "zh-CN",
                        "href": "/zh/article"
                    },
                    {
                        "hreflang": "x-default",
                        "href": "/article"
                    }
                ]
            },
            {
                "loc": "/zh/article",
                "_sitemap": "zh-CN",
                "alternatives": [
                    {
                        "hreflang": "id-ID",
                        "href": "/article"
                    },
                    {
                        "hreflang": "en-US",
                        "href": "/en/article"
                    },
                    {
                        "hreflang": "zh-CN",
                        "href": "/zh/article"
                    },
                    {
                        "hreflang": "x-default",
                        "href": "/article"
                    }
                ]
            },
            {
                "loc": "/principal",
                "_sitemap": "id-ID",
                "alternatives": [
                    {
                        "hreflang": "id-ID",
                        "href": "/principal"
                    },
                    {
                        "hreflang": "en-US",
                        "href": "/en/principal"
                    },
                    {
                        "hreflang": "zh-CN",
                        "href": "/zh/principal"
                    },
                    {
                        "hreflang": "x-default",
                        "href": "/principal"
                    }
                ]
            },
            {
                "loc": "/en/principal",
                "_sitemap": "en-US",
                "alternatives": [
                    {
                        "hreflang": "id-ID",
                        "href": "/principal"
                    },
                    {
                        "hreflang": "en-US",
                        "href": "/en/principal"
                    },
                    {
                        "hreflang": "zh-CN",
                        "href": "/zh/principal"
                    },
                    {
                        "hreflang": "x-default",
                        "href": "/principal"
                    }
                ]
            },
            {
                "loc": "/zh/principal",
                "_sitemap": "zh-CN",
                "alternatives": [
                    {
                        "hreflang": "id-ID",
                        "href": "/principal"
                    },
                    {
                        "hreflang": "en-US",
                        "href": "/en/principal"
                    },
                    {
                        "hreflang": "zh-CN",
                        "href": "/zh/principal"
                    },
                    {
                        "hreflang": "x-default",
                        "href": "/principal"
                    }
                ]
            },
            {
                "loc": "/profile",
                "_sitemap": "id-ID",
                "alternatives": [
                    {
                        "hreflang": "id-ID",
                        "href": "/profile"
                    },
                    {
                        "hreflang": "en-US",
                        "href": "/en/profile"
                    },
                    {
                        "hreflang": "zh-CN",
                        "href": "/zh/profile"
                    },
                    {
                        "hreflang": "x-default",
                        "href": "/profile"
                    }
                ]
            },
            {
                "loc": "/en/profile",
                "_sitemap": "en-US",
                "alternatives": [
                    {
                        "hreflang": "id-ID",
                        "href": "/profile"
                    },
                    {
                        "hreflang": "en-US",
                        "href": "/en/profile"
                    },
                    {
                        "hreflang": "zh-CN",
                        "href": "/zh/profile"
                    },
                    {
                        "hreflang": "x-default",
                        "href": "/profile"
                    }
                ]
            },
            {
                "loc": "/zh/profile",
                "_sitemap": "zh-CN",
                "alternatives": [
                    {
                        "hreflang": "id-ID",
                        "href": "/profile"
                    },
                    {
                        "hreflang": "en-US",
                        "href": "/en/profile"
                    },
                    {
                        "hreflang": "zh-CN",
                        "href": "/zh/profile"
                    },
                    {
                        "hreflang": "x-default",
                        "href": "/profile"
                    }
                ]
            },
            {
                "loc": "/promo",
                "_sitemap": "id-ID",
                "alternatives": [
                    {
                        "hreflang": "id-ID",
                        "href": "/promo"
                    },
                    {
                        "hreflang": "en-US",
                        "href": "/en/promo"
                    },
                    {
                        "hreflang": "zh-CN",
                        "href": "/zh/promo"
                    },
                    {
                        "hreflang": "x-default",
                        "href": "/promo"
                    }
                ]
            },
            {
                "loc": "/en/promo",
                "_sitemap": "en-US",
                "alternatives": [
                    {
                        "hreflang": "id-ID",
                        "href": "/promo"
                    },
                    {
                        "hreflang": "en-US",
                        "href": "/en/promo"
                    },
                    {
                        "hreflang": "zh-CN",
                        "href": "/zh/promo"
                    },
                    {
                        "hreflang": "x-default",
                        "href": "/promo"
                    }
                ]
            },
            {
                "loc": "/zh/promo",
                "_sitemap": "zh-CN",
                "alternatives": [
                    {
                        "hreflang": "id-ID",
                        "href": "/promo"
                    },
                    {
                        "hreflang": "en-US",
                        "href": "/en/promo"
                    },
                    {
                        "hreflang": "zh-CN",
                        "href": "/zh/promo"
                    },
                    {
                        "hreflang": "x-default",
                        "href": "/promo"
                    }
                ]
            },
            {
                "loc": "/",
                "_sitemap": "id-ID",
                "alternatives": [
                    {
                        "hreflang": "id-ID",
                        "href": "/"
                    },
                    {
                        "hreflang": "en-US",
                        "href": "/en"
                    },
                    {
                        "hreflang": "zh-CN",
                        "href": "/zh"
                    },
                    {
                        "hreflang": "x-default",
                        "href": "/"
                    }
                ]
            },
            {
                "loc": "/en",
                "_sitemap": "en-US",
                "alternatives": [
                    {
                        "hreflang": "id-ID",
                        "href": "/"
                    },
                    {
                        "hreflang": "en-US",
                        "href": "/en"
                    },
                    {
                        "hreflang": "zh-CN",
                        "href": "/zh"
                    },
                    {
                        "hreflang": "x-default",
                        "href": "/"
                    }
                ]
            },
            {
                "loc": "/zh",
                "_sitemap": "zh-CN",
                "alternatives": [
                    {
                        "hreflang": "id-ID",
                        "href": "/"
                    },
                    {
                        "hreflang": "en-US",
                        "href": "/en"
                    },
                    {
                        "hreflang": "zh-CN",
                        "href": "/zh"
                    },
                    {
                        "hreflang": "x-default",
                        "href": "/"
                    }
                ]
            }
        ],
        "sourceType": "app"
    }
];

export { sources };
//# sourceMappingURL=global-sources.mjs.map
