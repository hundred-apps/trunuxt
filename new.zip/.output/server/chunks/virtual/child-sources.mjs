const sources = {
    "id-ID": [],
    "en-US": [],
    "zh-CN": []
};

export { sources };
//# sourceMappingURL=child-sources.mjs.map
