import { x as defineEventHandler, y as sitemapIndexXmlEventHandler } from '../_/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'vue';
import 'consola';
import 'vue-router';
import 'node:fs';
import 'node:path';
import 'node:url';
import 'rou3';
import 'srvx';
import '@iconify/utils';
import 'node:crypto';
import 'fast-xml-parser';

const sitemap_index_xml = defineEventHandler(sitemapIndexXmlEventHandler);

export { sitemap_index_xml as default };
//# sourceMappingURL=sitemap_index.xml.mjs.map
